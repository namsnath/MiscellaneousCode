package wks1_Matrices;

import java.util.Scanner;

public class Wks1_Q8_SaddlePoint
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		System.out.println("Enter order of Matrix");
		int n = s.nextInt();
		int i = 0, j = 0, x = 0, rowMin[] = new int[n], colMax[] = new int[n];
		
		int A[][] = new int[n][n];
		
		System.out.println("Enter Elements of Array, Row-wise:");
		
		for(i = 0; i < n; i++)
		{
			for(j = 0; j < n; j++)
			{
				x = s.nextInt();
				if(x < 0) 
				{
					System.out.println("Please enter only positive Integers");
					System.exit(0);
				}
				A[i][j] = x;
			}
		}
		
		int max, min, f=0;
	       for(i = 0; i < n; i++)
	       {
	           min = A[i][0];
	           x = 0;
	           for(j = 0; j < n; j++)
	           {
	                if(A[i][j] < min)
	                {
	                    min = A[i][j];
	                    x = j;
	                }
	           }
	             
	          
	           max = A[0][x]; 
	           for(int k =0; k < n; k++)
	           {
	                if(A[k][x] > max)
	                {
	                    max = A[k][x];
	                }
	           }
	             
	           if(max == min)
	           {
	               System.out.println("Saddle point = "+max);
	               f=1;
	           }
	       }
	         
	       if(f==0)
	       {
	           System.out.println("No saddle point");
	       }
	}

}

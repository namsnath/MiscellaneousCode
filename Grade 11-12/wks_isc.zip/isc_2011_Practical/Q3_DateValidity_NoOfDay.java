package isc_2011_Practical;

import java.util.Scanner;

public class Q3_DateValidity_NoOfDay
{

	public static void main(String[] args)
	{
		Scanner s  = new Scanner(System.in);
		
		System.out.println("Enter your date of birth in dd mm yyyy format.");
		int d = s.nextInt();
		int m = s.nextInt();
		int y = s.nextInt();
		int days = 0;
		
		if(d <= 0 || m <= 0 || y <= 0 || d > 31 )
		{
			System.out.println("Invalid Date");
			System.exit(0);
		}

		
		if((y % 4 == 0 && d > 29 && m == 2) || (y % 4 != 0 && d > 28 && m == 2))
		{
			System.out.println("Invalid Date");
			System.exit(0);
		}
		if(m == 4 || m == 6 || m == 9 || m == 11)
		{
			if(d > 30)
			{
				System.out.println("Invalid Date");
				System.exit(0);
			}
		}
		
		switch(m)
		{
			case 12:	days += 30;
			
			case 11:	days += 31;
			
			case 10:	days += 30;
			
			case 9:		days += 31;
			
			case 8:		days += 31;
			
			case 7:		days += 30;
			
			case 6:		days += 31;
			
			case 5:		days += 30;
			
			case 4:		days += 31;
			
			case 3:		if(y % 4 == 0)
							days += 29;
						else
							days += 28;
			
			case 2:		days += 31;
		}
		
		days += d;
		
		System.out.println(days);
	}

}

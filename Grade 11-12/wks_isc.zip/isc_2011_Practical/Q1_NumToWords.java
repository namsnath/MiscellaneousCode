package isc_2011_Practical;

import java.util.Scanner;

public class Q1_NumToWords
{

	public static void main(String[] args)
	{
		String[] s_units = {"", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine"};
		String[] s_Tens = {"", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"};
		String[] s_Teens = {"Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Sevnteen", "Eighteen", "Nineteen"};
		
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter Number between 0 and 1000 (Exclusive)");
		int n = s.nextInt();
		if(n <= 0 || n >= 1000)
		{
			System.out.println("Value out of Range");
			System.exit(0);
		}
		
		StringBuffer st = new StringBuffer(Integer.toString(n));
		st.reverse();
		int l = st.length();
		
		if(l < 3)
			for(int i = 0; i < 3 - l; i++)
				st.append(0);
		
		st.reverse();
		
		char digits[] = st.toString().toCharArray();
		
		if(Character.getNumericValue(digits[1]) != 1 && Character.getNumericValue(digits[0]) != 0) //Contains Hundreds Digits and does not belong to 10-19
			System.out.println(s_units[Character.getNumericValue(digits[0])] + " Hundred " + s_Tens[Character.getNumericValue(digits[1])] + " " + s_units[Character.getNumericValue(digits[2])]);
		
		if(Character.getNumericValue(digits[1]) == 1 && Character.getNumericValue(digits[0]) != 0) // Contains Hundreds Digits and belongs to 10-19
			System.out.println(s_units[Character.getNumericValue(digits[0])] + " Hundred " + s_Teens[Character.getNumericValue(digits[2])]);
		
		if(Character.getNumericValue(digits[1]) != 1 && Character.getNumericValue(digits[0]) == 0) // Does not Contain Hundred's Digit and does not Belong to 10-19
			System.out.println(s_Tens[Character.getNumericValue(digits[1])] + " " +  s_units[Character.getNumericValue(digits[2])]);
		
		if(Character.getNumericValue(digits[1]) == 1 && Character.getNumericValue(digits[0]) == 0) //Does Not Contain Hundred's Digit and Belongs to 10-19
			System.out.println(s_Teens[Character.getNumericValue(digits[2])]);
	}

}
